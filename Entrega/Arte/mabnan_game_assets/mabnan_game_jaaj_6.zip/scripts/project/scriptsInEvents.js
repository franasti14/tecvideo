"use strict";


runOnStartup(async runtime =>
{

	runtime.callFunction("TocarMusica", "menu", 0);
	
});

function teste(runtime){

	/*
	var obj = runtime.objects.jogador;
	if(obj){
		obj = obj.getFirstInstance();
		if(obj.behaviors.Plataforma.isJumping){
			console.log("pulando");
		}
		if(obj.behaviors.Plataforma.isFalling){
			console.log("caindo");
		}
	}
	*/
	

	var layout = runtime.layout.name;

	switch(layout){
		case "Layout 1": runtime.goToLayout("Intro"); break;
		case "Intro": runtime.goToLayout("Principal");runtime.callFunction("TocarMusica", "jogo", -19); break;
		case "Principal": runtime.goToLayout("Final");runtime.callFunction("TocarMusica", "menu", 0); break;
		//case "Final": window.location.href="https://conradosaud.itch.io/mabnan";  break;
	}
}


{
	const scriptsInEvents = {

		async FolhaDeEventos1_Event38_Act1(runtime, localVars)
		{
			teste(runtime);
		}

	};
	
	self.C3.ScriptsInEvents = scriptsInEvents;
}
